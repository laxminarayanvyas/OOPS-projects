public interface AdminInterface {
    public void addBookInfo(); //add book info by admin
    public int calculateFine(String a); //calculation of fine
}
